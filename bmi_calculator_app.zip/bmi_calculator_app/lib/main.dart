import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;


void main() => runApp(BMICalculatorApp());

class BMICalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'BMI Calculator',
      theme: ThemeData(
        primaryColor: Colors.blue,
      ),
      home: BMICalculatorScreen(),
    );
  }
}

class BMICalculatorScreen extends StatefulWidget {
  @override
  _BMICalculatorScreenState createState() => _BMICalculatorScreenState();
}

class _BMICalculatorScreenState extends State<BMICalculatorScreen> {
  double _height = 160.0;
  double _weight = 60.0;
  double _bmi = 0.0;

  void _calculateBMI() {
    setState(() {
      _bmi = _weight / ((_height / 100) * (_height / 100));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Image.asset(
              'assets/bmi.png',
              width: 30.0,
              height: 30.0,
            ),
            SizedBox(width: 8.0),
            Text('BMI Calculator'),
          ],
        ),
      ),
      body: Container(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Height (cm)',
              style: TextStyle(fontSize: 16.0),
            ),
            TextFormField(
              initialValue: _height.toString(),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  _height = double.parse(value);
                });
              },
            ),
            Text(
              'Weight (kg)',
              style: TextStyle(fontSize: 16.0),
            ),
            TextFormField(
              initialValue: _weight.toString(),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                setState(() {
                  _weight = double.parse(value);
                });
              },
            ),
            SizedBox(height: 20.0),
            ElevatedButton(
              onPressed: _calculateBMI,
              child: Text('Calculate'),
            ),
            SizedBox(height: 20.0),
            Text(
              'BMI: ${_bmi.toStringAsFixed(1)}',
              style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}