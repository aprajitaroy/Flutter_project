package com.example.calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
