package com.example.package_use_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
