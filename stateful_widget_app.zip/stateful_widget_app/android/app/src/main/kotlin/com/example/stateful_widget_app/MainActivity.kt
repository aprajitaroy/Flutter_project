package com.example.stateful_widget_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
