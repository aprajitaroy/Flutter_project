import 'package:flutter/material.dart';

void main() {
  runApp(QuizApp());
}

class QuizApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'True/False Quiz App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: QuizPage(),
    );
  }
}

class QuizPage extends StatefulWidget {
  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  List<Question> _questions = [
    Question('Flutter is a mobile app development framework.', true),
    Question('Dart is the programming language used in Flutter.', true),
    Question('Widgets in Flutter are immutable.', true),
    Question('Flutter is developed by Facebook.', false),
  ];

  int _questionIndex = 0;
  int _score = 0;

  void _checkAnswer(bool userAnswer) {
    bool correctAnswer = _questions[_questionIndex].answer;
    if (userAnswer == correctAnswer) {
      _score++;
    }
    setState(() {
      _questionIndex++;
    });
  }

  void _resetQuiz() {
    setState(() {
      _questionIndex = 0;
      _score = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('True/False Quiz App'),
      ),
      body: _questionIndex < _questions.length
          ? QuizQuestion(
        question: _questions[_questionIndex],
        checkAnswer: _checkAnswer,
      )
          : QuizResult(
        score: _score,
        totalQuestions: _questions.length,
        resetQuiz: _resetQuiz,
      ),
    );
  }
}

class Question {
  final String questionText;
  final bool answer;

  Question(this.questionText, this.answer);
}

class QuizQuestion extends StatelessWidget {
  final Question question;
  final Function(bool) checkAnswer;

  QuizQuestion({required this.question, required this.checkAnswer});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            question.questionText,
            style: TextStyle(fontSize: 24),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              ElevatedButton(
                onPressed: () {
                  // Delay the call to setState() until after the current frame has finished building
                  Future.microtask(() => checkAnswer(true));
                },
                child: Text('True'),
              ),
              SizedBox(width: 20),
              ElevatedButton(
                onPressed: () {
                  // Delay the call to setState() until after the current frame has finished building
                  Future.microtask(() => checkAnswer(false));
                },
                child: Text('False'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class QuizResult extends StatelessWidget {
  final int score;
  final int totalQuestions;
  final Function resetQuiz;

  QuizResult({required this.score, required this.totalQuestions, required this.resetQuiz});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text(
            'Quiz Completed!',
            style: TextStyle(fontSize: 24),
          ),
          SizedBox(height: 20),
          Text(
            'Score: $score/$totalQuestions',
            style: TextStyle(fontSize: 20),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () => resetQuiz(),
            child: Text('Restart Quiz'),
          ),
        ],
      ),
    );
  }
}
